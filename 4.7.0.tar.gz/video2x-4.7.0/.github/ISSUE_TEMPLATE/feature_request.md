---
name: Feature request
about: Request a new feature to be added
title: ''
labels: enhancement
assignees: K4YT3X

---

## Description

Briefly describe the feature that you'd like Video2X to have.

## Sources

Paste links to descriptions of related documentations, websites and etc. here.
